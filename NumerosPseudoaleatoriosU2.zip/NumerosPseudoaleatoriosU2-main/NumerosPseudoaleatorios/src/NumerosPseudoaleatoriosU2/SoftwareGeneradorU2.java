
package NumerosPseudoaleatoriosU2;

import java.io.IOException;

/**
 *
 * @author Adrian Leonardo
 */
public class SoftwareGeneradorU2 {

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        framePrincipal prueba = new framePrincipal();
        prueba.setVisible(true);
    }
    
}
